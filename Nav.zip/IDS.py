from Address import get_address

def ids_with_backtracking(matrix, start, goal, max_depth):
    start=start[0]
    def dfs_recursive(current_state, depth, path):
        if current_state == goal:
            print("Path found:", path + [current_state])
            return True

        if depth == 0:
            return False

        x, y = current_state
        addresses = get_address(matrix, x, y,visited=[])

        for address in addresses:
            if address not in path:  # Avoid revisiting nodes
                if dfs_recursive(address, depth - 1, path + [current_state]):
                    return True

        return False

    for depth in range(max_depth + 1):
        if dfs_recursive(start, depth, []):
            return True

    return False



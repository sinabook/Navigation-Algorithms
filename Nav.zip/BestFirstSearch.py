from queue import PriorityQueue
from Address import get_address
from Hueristic import Heuristic
def best_first_search(matrix, start, goals):
    counter=0
    count_of_T = sum(cell.count('T') for row in matrix for cell in row)

    visited = set()
    start=start[0]
    priority_queue = PriorityQueue()
    priority_queue.put((0, start))

    while not priority_queue.empty():
        _, current_state = priority_queue.get()
        if "T" in matrix[current_state[0]][current_state[1]] and counter==count_of_T:
            return True,visited 
        if "T" in matrix[current_state[0]][current_state[1]] and counter!=count_of_T:
            counter+=1
        x, y = current_state
        addresses = get_address(matrix,x, y,visited=visited)

        for address in addresses:
            if address not in visited:
                if(Heuristic(matrix, address,goals,visited=visited)[3]):
                    priority=Heuristic(matrix, address,goals,visited=visited)[3]
                else:
                    priority=0
                priority_queue.put((priority, address))
                visited.add(address)
        
    return False,visited  


